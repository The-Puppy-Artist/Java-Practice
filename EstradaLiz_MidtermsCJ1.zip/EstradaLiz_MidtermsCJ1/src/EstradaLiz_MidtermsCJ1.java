import java.util.Scanner;

public class EstradaLiz_MidtermsCJ1 {

    Scanner input = new Scanner(System.in);

    int leftMissionaries = 3;
    int leftCannibals = 3;
    int rightMissionaries = 0;
    int rightCannibals = 0;

    // true = left bank, false = right bank
    boolean boatOnLeft = true;

    public static void main(String[] args) {
        EstradaLiz_MidtermsCJ1 game = new EstradaLiz_MidtermsCJ1();
                game.runGame();
    }

    //Runs the game
    public void runGame() {
        boolean playAgain;
        do {
            resetGame();
            do {
                printCurrentState();
            } while (processMove());
            System.out.println("Play Again? (Y/N): ");
            String response = input.next();
            playAgain = response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes");
        } while (playAgain);
        System.out.println("Terminating program. Thank you for playing.");
        input.close();
    }

    //Resets the game back to its usual state if user wants to play again
    public void resetGame() {
        leftMissionaries = 3;
        leftCannibals = 3;
        rightMissionaries = 0;
        rightCannibals = 0;
        boatOnLeft = true;
    }

    //Arrays used to build a crude visual
    public String[] buildVisuals(int mCount, int cCount) {
        String[] visualArray = new String[mCount + cCount];
        int index = 0;

        for (int i = 0; i < mCount; i++) {
            visualArray[index++] = "M";
        }
        for (int i = 0; i < cCount; i++) {
            visualArray[index++] = "C";
        }
        return visualArray;
    }

    //Formatting for the array into a single string for printing later
    public String formatVisuals(String[] visualArray) {
        String result = "";
        for (int i = 0; i < visualArray.length; i++) {
            result += visualArray[i] + " ";
        }
        return result;
    }

    //Calls the last two functions (the array builder, then the formatter), and combines them into one before being printed
    public void printCurrentState() {
        // Calls and Generates the visual arrays made earlier
        String[] leftVisual = buildVisuals(leftMissionaries, leftCannibals);
        String[] rightVisual = buildVisuals(rightMissionaries, rightCannibals);

        //Formatting of arrays and visuals
        String leftString = formatVisuals(leftVisual);
        String rightString = formatVisuals(rightVisual);

        //Below are the crude drawings
        if (boatOnLeft) {
            System.out.println(leftString + " \\___/ ~~~~~ " + rightString);
        } else {
            System.out.println(leftString + " ~~~~~ \\___/ " + rightString);
        }
        System.out.println("================================"); //Separator
    }

    //Method to safely grab integers

    public boolean processMove() {
        System.out.print("Missionaries to move: ");
        int moveM = input.nextInt();

        System.out.print("Cannibals to move: ");
        int moveC = input.nextInt();

        if (moveM + moveC < 1 || moveM + moveC > 2) {
            System.out.println("Invalid! Boat can only contain up to 2 passengers, and no less than 1");
            return true;
        }
        if (boatOnLeft) {
            if (moveM > leftMissionaries || moveC > leftCannibals) {
                System.out.println("Invalid! Not enough people to move from the left");
                return true;
            }
            leftMissionaries -= moveM;
            leftCannibals -= moveC;
            rightMissionaries += moveM;
            rightCannibals += moveC;
            boatOnLeft = false;
        } else {
            if (moveM > rightMissionaries || moveC > rightCannibals) {
                System.out.println("Invalid! Not enough people on the Right Bank.");
                return true;
            }
            rightMissionaries -= moveM;
            rightCannibals -= moveC;
            leftMissionaries += moveM;
            leftCannibals += moveC;
            boatOnLeft = true;
        }
        if (rightMissionaries == 3 && rightCannibals == 3) {
            System.out.println("\nYOU WIN!");
            System.out.println("All Missionaries and Cannibals safely crossed the river");
            printFinalState();
            return false; // Stop inner loop
        }
        // Check Loss Condition
        else if ((leftCannibals > leftMissionaries && leftMissionaries > 0) ||
                (rightCannibals > rightMissionaries && rightMissionaries > 0)) {
            System.out.println("\nYOU LOST!");
            System.out.println("The Cannibals outnumbered the Missionaries...");
            printFinalState();
            return false; // Stop inner loop
        }

        return true; // Game continues
    }

    public void printFinalState() {
        System.out.println("\n--- FINAL STATE ---");
        System.out.println("Left Bank: " + leftMissionaries + " M || " + leftCannibals + " C");
        System.out.println("Right Bank: " + rightMissionaries + " M || " + rightCannibals + " C");
    }
}
